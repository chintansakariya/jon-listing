<?php
/**
 * Plugin Name: Job Listings API
 * Plugin URI:  https://yourwebsite.com/
 * Description: A custom plugin to manage job listings with REST API and admin settings.
 * Version:     1.0
 * Author:      Your Name
 * Author URI:  https://yourwebsite.com/
 * License:     GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

// Include necessary files
require_once plugin_dir_path(__FILE__) . 'includes/cpt.php';
require_once plugin_dir_path(__FILE__) . 'includes/rest-api.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin-settings.php';
require_once plugin_dir_path(__FILE__) . 'includes/shortcode.php';
