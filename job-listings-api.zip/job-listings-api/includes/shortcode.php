<?php
if (!defined('ABSPATH')) exit;

function job_listings_shortcode() {
    $query = new WP_Query(['post_type' => 'job_listing', 'posts_per_page' => -1]);
    if (!$query->have_posts()) return "<p>No job listings available.</p>";

    $output = '<ul class="job-listings">';
    while ($query->have_posts()) {
        $query->the_post();
        $output .= '<li><a href="' . get_permalink() . '">' . get_the_title() . '</a></li>';
    }
    wp_reset_postdata();
    return $output . '</ul>';
}
add_shortcode('job_listings', 'job_listings_shortcode');
