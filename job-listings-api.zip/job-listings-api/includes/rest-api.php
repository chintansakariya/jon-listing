<?php
if (!defined('ABSPATH')) exit;

function register_job_listings_endpoint() {
    register_rest_route('jobs/v1', '/listings', array(
        'methods'  => 'GET',
        'callback' => 'get_job_listings',
        'permission_callback' => '__return_true' // Open API (can add authentication later)
    ));
}
add_action('rest_api_init', 'register_job_listings_endpoint');

function get_job_listings() {
    // Check if API access is enabled
    $enable_api = get_option('job_api_enabled', 'yes');
    if ($enable_api !== 'yes') {
        return new WP_Error('api_disabled', 'API access is disabled.', ['status' => 403]);
    }

    // Get job limit from settings
    $limit = get_option('job_api_limit', 10);

    $args = array(
        'post_type'      => 'job_listing',
        'posts_per_page' => intval($limit),
        'post_status'    => 'publish',
    );

    $query = new WP_Query($args);
    if (!$query->have_posts()) {
        return new WP_REST_Response(['message' => 'No jobs found'], 200);
    }

    $jobs = [];
    while ($query->have_posts()) {
        $query->the_post();
        $job_id = get_the_ID();
        
        // Get salary details with fallback
        $salary_min = get_post_meta($job_id, 'salary_min', true);
        $salary_max = get_post_meta($job_id, 'salary_max', true);
        $salary_range = ($salary_min && $salary_max) ? "{$salary_min} - {$salary_max}" : 'Not specified';

        $jobs[] = array(
            'job_title'            => esc_html(get_the_title()),
            'company_name'         => esc_html(get_post_meta($job_id, 'company_name', true) ?: 'Not specified'),
            'job_location'         => esc_html(get_post_meta($job_id, 'job_location', true) ?: 'Not specified'),
            'salary_range'         => esc_html($salary_range),
            'application_deadline' => esc_html(get_post_meta($job_id, 'application_deadline', true) ?: 'Not specified'),
            'permalink'            => esc_url(get_permalink()),
        );
    }
    wp_reset_postdata();

    return new WP_REST_Response($jobs, 200);
}

