<?php 
if (!defined('ABSPATH')) exit;

// Register Custom Post Type for Job Listings
function register_job_listings_cpt() {
    $args = array(
        'label'         => __('Job Listings', 'textdomain'),
        'public'        => true,
        'show_in_rest'  => true, // Enables REST API
        'menu_icon'     => 'dashicons-businessman',
        'supports'      => array('title', 'editor', 'thumbnail'),
        'has_archive'   => true,
        'rewrite'       => array('slug' => 'jobs'),
        'publicly_queryable' => true,
    );
    register_post_type('job_listing', $args);
}
add_action('init', 'register_job_listings_cpt');

// Register Meta Fields (Fixed floatval() issue)
function register_job_meta_fields() {
    $meta_fields = [
        'company_name'         => 'string', // Text
        'job_location'         => 'string', // Text
        'salary_min'           => 'number', // Minimum Salary
        'salary_max'           => 'number', // Maximum Salary
        'application_deadline' => 'string', // Date
    ];

    foreach ($meta_fields as $key => $type) {
        register_post_meta('job_listing', $key, [
            'show_in_rest' => true,
            'single' => true,
            'type' => $type,
            'sanitize_callback' => ($type === 'number') ? function($value) { return floatval($value); } : 'sanitize_text_field',
        ]);
    }
}
add_action('init', 'register_job_meta_fields');

// Add Meta Box to Job Listings
function job_listings_add_meta_box() {
    add_meta_box(
        'job_details_meta_box',
        'Job Details',
        'job_listings_meta_box_callback',
        'job_listing',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'job_listings_add_meta_box');

// Callback for Meta Box
function job_listings_meta_box_callback($post) {
    wp_nonce_field('job_listings_save_meta_box', 'job_listings_meta_box_nonce');

    $fields = [
        'company_name'         => 'text',
        'job_location'         => 'text',
        'salary_min'           => 'number',
        'salary_max'           => 'number',
        'application_deadline' => 'date'
    ];
    
    foreach ($fields as $field => $type) {
        $value = get_post_meta($post->ID, $field, true);
        echo '<p><label for="' . esc_attr($field) . '">' . ucfirst(str_replace('_', ' ', $field)) . ':</label>';
        echo '<input type="' . esc_attr($type) . '" id="' . esc_attr($field) . '" name="' . esc_attr($field) . '" value="' . esc_attr($value) . '" class="widefat"></p>';
    }
}

// Save Meta Box Data
function job_listings_save_meta_box($post_id) {
    // Verify Nonce
    if (!isset($_POST['job_listings_meta_box_nonce']) || 
        !wp_verify_nonce($_POST['job_listings_meta_box_nonce'], 'job_listings_save_meta_box')) {
        return;
    }

    // Prevent Autosave Overwrites
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    // Check User Permissions
    if (!current_user_can('edit_post', $post_id)) return;

    // Define Fields
    $fields = [
        'company_name'         => 'text',
        'job_location'         => 'text',
        'salary_min'           => 'number',
        'salary_max'           => 'number',
        'application_deadline' => 'date'
    ];

    // Save Fields
    foreach ($fields as $field => $type) {
        if (isset($_POST[$field])) {
            $value = sanitize_text_field($_POST[$field]);

            // Validate number fields
            if ($type === 'number') {
                $value = intval($value);  // Ensure it's stored as an integer
            }
            // Ensure date is stored properly
            elseif ($type === 'date') {
                $value = date('Y-m-d', strtotime($value)); // Store as YYYY-MM-DD format
            }

            update_post_meta($post_id, $field, $value);
        }
    }
}
add_action('save_post', 'job_listings_save_meta_box');
?>
