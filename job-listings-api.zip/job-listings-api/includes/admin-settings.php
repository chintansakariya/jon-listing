<?php
if (!defined('ABSPATH')) exit;

function job_api_settings_page() {
    add_options_page('Job Listings API', 'Job Listings API', 'manage_options', 'job-api-settings', 'job_api_settings_page_html');
}
add_action('admin_menu', 'job_api_settings_page');

function job_api_settings_page_html() {
    if (!current_user_can('manage_options')) return;

    // Save settings
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        check_admin_referer('job_api_settings_save', 'job_api_nonce');
        
        // Update API limit
        if (isset($_POST['job_api_limit'])) {
            update_option('job_api_limit', intval($_POST['job_api_limit']));
        }
        
        // Update API toggle (enabled/disabled)
        $enabled = isset($_POST['job_api_enabled']) ? 'yes' : 'no';
        update_option('job_api_enabled', $enabled);

        echo '<div class="updated"><p>Settings saved!</p></div>';
    }

    // Debug the value retrieved from the database
    $api_enabled = get_option('job_api_enabled', 'yes'); // Default is 'yes'
    $limit = get_option('job_api_limit', 10);

    // Debugging output (remove after testing)
    echo "<pre>Debug: job_api_enabled = " . esc_html($api_enabled) . "</pre>";

    ?>
    
    <div class="wrap">
        <h2>Job Listings API Settings</h2>
        <form method="POST">
            <?php wp_nonce_field('job_api_settings_save', 'job_api_nonce'); ?>

            <p>
                <label for="job_api_enabled"><strong>Enable API:</strong></label>
                <input type="checkbox" name="job_api_enabled" id="job_api_enabled" value="yes" <?php echo ($api_enabled === 'yes') ? 'checked' : ''; ?>>
            </p>

            <p>
                <label for="job_api_limit"><strong>Number of Jobs to Display:</strong></label>
                <input type="number" name="job_api_limit" id="job_api_limit" value="<?php echo esc_attr($limit); ?>" min="1" required>
            </p>

            <button type="submit" class="button button-primary">Save Settings</button>
        </form>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            let toggleCheckbox = document.getElementById("job_api_enabled");
            let jobLimitInput = document.getElementById("job_api_limit");

            function toggleJobLimit() {
                jobLimitInput.disabled = !toggleCheckbox.checked;
            }

            toggleCheckbox.addEventListener("change", toggleJobLimit);
            toggleJobLimit(); // Run on page load
        });
    </script>
    
    <?php
}
